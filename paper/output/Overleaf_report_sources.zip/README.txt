Select task1_standalone.tex or task2_standalone.tex as the main document.
main.tex is the combined working report. Compile twice to resolve references.
Task 1: 4500 words approved. Task 2: uncapped. Two columns and extra pages approved.
